package com.example.msdgymapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpperBody extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upper_body);
    }
}